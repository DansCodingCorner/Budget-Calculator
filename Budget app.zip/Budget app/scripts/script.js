
//Imitialize aand gather relevant elements
const add_button = document.getElementById('add-item');
const remove_button = document.getElementById('remove-item');
const create_budget_button = document.getElementById('create-budget');
const budget_entry_template = document.querySelector('.budget-entry');
const budget_container = document.querySelector('.budget-container');
const pie_chart = document.getElementById('pie-chart');
const total_div = document.getElementById('total-div');
const total_span = document.getElementById('total');

//Add event listeners to relevant elements
add_button.addEventListener('click' , add_element);
remove_button.addEventListener('click', remove_item)
create_budget_button.addEventListener('click', create_budget)

function add_element()
{
    //This function is used to add a new budget entry element
    const new_budget_entry = budget_entry_template.cloneNode(true);
    
    new_budget_entry.querySelector('.item-title').value = '';
    new_budget_entry.querySelector('.amount').value = '';
    
    budget_container.appendChild(new_budget_entry);
}

function remove_item()
{
    element_to_remove = document.querySelector('.budget-entry:last-child');
    if(element_to_remove)
    {
        element_to_remove.remove()
    }
    else
    {
        alert('There must be at least one element to remove')
    }
}

function create_budget()
{
    total_span.innerHTML = calculate_total() + '$';
    total_div.style.visibility = 'visible';


    var data = [{values: get_values(),
    labels: get_titles(),
    type: 'pie'}];

    var layout = {height: 400,width: 500};
    Plotly.newPlot(pie_chart, data, layout);

}

function calculate_total()
{
    let amounts_elements = document.getElementsByClassName('amount');
    let values = []

    for(index = 0 ; index < amounts_elements.length ; index ++)
    {
        values.push(parseFloat(amounts_elements[index].value));
    }
    let total = 0

    for(value = 0 ; value<values.length ; value ++)
    {
        total += parseFloat(values[value]);
    }

    return total;
}

function get_values()
{
    let amounts_elements = document.getElementsByClassName('amount');
    let values = []

    for(index = 0 ; index < amounts_elements.length ; index ++)
    {
        values.push(parseFloat(amounts_elements[index].value));
    }
    return values
}

function get_titles()
{
    let titles_elements = document.getElementsByClassName('item-title');
    let titles = []

    for(index = 0 ; index < titles_elements.length ; index ++)
    {
        titles.push(titles_elements[index].value);
    }
    return titles
}